# pico-latex-presentation
This is a repository to collect ideas for a Latex document to produce a PICO presentation for the EGU conference.

There is a pdf as preview to see the result. The document will not compile because most figures are missing, so edit the source or add you own image.
